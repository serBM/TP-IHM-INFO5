# TP1 IHM Avancée - INFO5 Polytech - 2019-2020

Le but de ce premier TP est d'implémenter un Range Slider. Le sujet détaillé est disponible sur ce dépot Git.

**Deadline de remise du TP :**  Vendredi 18 octobre 2019 à 8h du matin.

**Membres du groupe :** VANDAL Jade, VINCENT Maxence, THOMAS Antoine


# Explications

    écrire ici intro

## Choix de conception

    écrire ici

## Éléments implémentés

    écrire ici

## Mode d'utilisation

    écrire ici

